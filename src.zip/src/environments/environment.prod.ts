export const environment = {
  production: true,
  baseUrl: 'https://api.truneek.com/graphql',
  ImageS3Url: 'https://truneek.s3.ap-south-1.amazonaws.com'
};
