import { Injectable } from '@angular/core';
import { Page } from './page';
import { Contact } from './contact';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpBackend } from '@angular/common/http';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { Apollo, QueryRef } from 'apollo-angular';
import gql from 'graphql-tag';

@Injectable({
  providedIn: 'root'
})
export class CmspageService {

  ServerUrl = environment.baseUrl;
  errorData: {};
  private query: QueryRef<any>;

  httpOptions = {
    headers: new HttpHeaders({'Content-Type': 'application/json'})
  };

  private http: HttpClient;

  constructor(private apollo: Apollo,handler: HttpBackend) {
      this.http = new HttpClient(handler);
  }

  getPages(aPageName) {
    const Page_QUERY = gql`
    query  getPages($aParamPageName: [String]!){
      getPages(name:$aParamPageName){
        id
        page_name
        page_description
        
      }
    }
  `;    
  this.query = this.apollo.watchQuery({
    query: Page_QUERY,
    variables: { aParamPageName: aPageName }
  });

  return this.query;
 
  }
  
getSlugPage(PageSlug) {
    const PageSlug_QUERY = gql`
    query  getSlugPage($ParamPageSlug: String!){
      getSlugPage(slug:$ParamPageSlug){
        id
        page_name
        page_description
      }
    }
    `;    

    this.query = this.apollo.watchQuery({
      query: PageSlug_QUERY,
      variables: { ParamPageSlug: PageSlug }
    });

    return this.query;
  }


  getcontactForm(formdata: Contact) {
    const Contact_QUERY = gql`
    query  {
      contact {
        name
        email
        phone
        message
      }
    }
  `;
    this.query = this.apollo.watchQuery({
      query: Contact_QUERY,
      //variables: {offset : 10*this.page}
    });

    return this.query;

  }
  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    this.errorData = {
      errorTitle: 'Oops! Request for document failed',
      errorDesc: 'Something bad happened. Please try again later.'
    };
    return throwError(this.errorData);
  }
}
