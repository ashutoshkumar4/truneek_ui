import { Component, OnInit} from '@angular/core';
import { CmspageService } from '../cmspage.service';
import { Contact } from '../contact';
import { Router } from '@angular/router';
//import {} from 'googlemaps';
import * as _ from 'lodash'; 

@Component({
  selector: 'app-contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.css']
})
export class ContactFormComponent implements OnInit {

  model = new Contact();
  submitted = false;
  error = {};
  ContactData: any;
  lat: number = 28.46353;
  lng: number =  77.076950;

  constructor(
    private router: Router,
    private _cmspageService: CmspageService
  ) { }

  ngOnInit() {
    var aConfigPages = ["header-contact"];

    this._cmspageService.getPages(aConfigPages).valueChanges.subscribe(
      (result) => {
        this.ContactData = result.data && result.data.getPages;
        this.ContactData = _.find(this.ContactData, { 'page_name': 'header-contact'});
        this.ContactData =  this.ContactData.page_description;

      },
      error => this.error = error
    );
  }

  onSubmit() {
    this.submitted = true;
    return this._cmspageService.getcontactForm(this.model).valueChanges.subscribe(
      (result) => {
        this.model = result.data && result.data.contact;
        },
      error => this.error = error
    );
  }

  gotoHome() {
    this.router.navigate(['/']);
  }

}
