import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { CmspageRoutingModule } from './cmspage-routing.module';
import { PageComponent } from './page/page.component';
import { ContactFormComponent } from './contact-form/contact-form.component';
import { AgmCoreModule } from '@agm/core';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    CmspageRoutingModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyBkz0YPZ6sQvGqdoxn7BKiyKq5GYb6EKko'
    })
  ],
  declarations: [PageComponent, ContactFormComponent]
})
export class CmspageModule { }
