export class Page {
    id: number;
    page_name: string;
    page_description: string;
}
