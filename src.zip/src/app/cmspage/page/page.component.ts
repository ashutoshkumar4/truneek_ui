import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { CmspageService } from '../cmspage.service';
import { Page } from '../page';
import { switchMap } from 'rxjs/operators';
import * as _ from 'lodash'; 

import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-page',
  templateUrl: './page.component.html',
  styleUrls: ['./page.component.css']
})
export class PageComponent implements OnInit {

  page: Page;
  error: {};

  constructor(
    private route: ActivatedRoute,
    private cmspageService: CmspageService,
    protected html_sanitizer: DomSanitizer
    ) { }

  sameAsHtml(html_content) {
   return this.html_sanitizer.bypassSecurityTrustHtml(html_content);
  }

  ngOnInit() {
     
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) =>
        this.cmspageService.getSlugPage(params.get('slug')).valueChanges
      )
    ).subscribe(
      (result) => {
        this.page =  result.data && result.data.getSlugPage;
        },
      error => {this.error = error;console.log(this.error);}
      );
  }

}
