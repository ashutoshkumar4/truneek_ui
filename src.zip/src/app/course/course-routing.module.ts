import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CourseDetailComponent } from './course-detail/course-detail.component';

const routes: Routes = [
  {path: 'course/:id', component: CourseDetailComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes),
    RouterModule.forRoot(routes,{
      anchorScrolling: 'enabled'
    })
  ],
  exports: [RouterModule]
})
export class CourseRoutingModule { }
