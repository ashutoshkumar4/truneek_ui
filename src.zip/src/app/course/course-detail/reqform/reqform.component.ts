import { Component, OnInit , Input} from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { CourseService } from '../../course.service';
import { Observable } from 'rxjs';
import {
  mergeMap, switchMap, retry,
  map, catchError, filter, scan
} from 'rxjs/operators';

@Component({
  selector: 'app-reqform',
  templateUrl: './reqform.component.html',
  styleUrls: ['./reqform.component.css']
})
export class ReqformComponent implements OnInit {
  ReqInfoForm: FormGroup;
  submitted = false;
  ReqInfoError: string;
  ReqInfoSuccess: string;
  bIndividualsImg = true;
  bBusinessImg = false;
  sPlaceReqName:string = 'Name';
  error: '';
  
  @Input() reqCourseID: number;

  constructor(
    private fb: FormBuilder,
    private _courseService: CourseService,
  ) { }

  ngOnInit() {

    this.createForm();
  }
  createForm() {
    this.ReqInfoForm = this.fb.group({
      ReqName: ['', Validators.required],
      ReqEmail: ['', [Validators.required, Validators.email]],
      ReqMobileNo: ['', Validators.required],
      ReqYourMessage: [''],
      ReqPolicy: ['',Validators.requiredTrue],

    });
  }
  get ReqName() { return this.ReqInfoForm.get('ReqName'); }
  get ReqCompanyName() { return this.ReqInfoForm.get('ReqCompanyName'); }
  get ReqEmail() { return this.ReqInfoForm.get('ReqEmail'); }
  get ReqMobileNo() { return this.ReqInfoForm.get('ReqMobileNo'); }
  get ReqYourMessage() { return this.ReqInfoForm.get('ReqYourMessage'); }
  get ReqPolicy() { return this.ReqInfoForm.get('ReqPolicy'); }
  ToggeleImage(sImageMame) {
    this.ReqInfoError = '';
    this.ReqInfoSuccess = '';
    if (sImageMame == 'individuals') {
      this.bIndividualsImg = true;
      this.bBusinessImg = false;
      this.sPlaceReqName = 'Name';

    }
    if (sImageMame == 'business') {
      this.bIndividualsImg = false;
      this.bBusinessImg = true;
      this.sPlaceReqName = 'Company Name';
    }
  }
  onSubmit() {
    this.submitted = true;
    this.ReqInfoError = '';
    this.ReqInfoSuccess = '';

    var objFormVals = this.ReqInfoForm.value;

    if(this.bBusinessImg)
      objFormVals.Individuals = this.bBusinessImg;
    else
      objFormVals.Individuals = this.bIndividualsImg;


    objFormVals.courses_id = this.reqCourseID;
    this._courseService.CreateContactInfo(
      objFormVals.ReqName,
      objFormVals.ReqEmail,
      objFormVals.ReqMobileNo,
      objFormVals.courses_id,
      objFormVals.Individuals,
      objFormVals.ReqYourMessage).subscribe(
        (result) => {
        //  console.log("my result " + JSON.stringify(result.data));
          this.ReqInfoSuccess = 'Information submitted successfully';
          this.ReqInfoError = '';

        },
        error => {
        // console.log("my error " + JSON.stringify(error.message));
         this.ReqInfoSuccess = '';
         this.ReqInfoError = "Something went wrong. Please try again.";
        }
      );
  }

}

