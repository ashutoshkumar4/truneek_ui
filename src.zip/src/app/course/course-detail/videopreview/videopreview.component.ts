import { Component, OnInit,Inject,Input } from '@angular/core';
import {DomSanitizer,SafeResourceUrl,} from '@angular/platform-browser'
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-videopreview',
  templateUrl: './videopreview.component.html',
  styleUrls: ['./videopreview.component.css']
})
export class VideopreviewComponent implements OnInit {
  public VideoUrl: SafeResourceUrl;
  @Input() fileURL;

  constructor(
  public sanitizer:DomSanitizer,
  public activeModal: NgbActiveModal
  ) { 
   // console.log("data >>"+JSON.stringify(data.sDialogTopicVideoUrl));
  // this.VideoUrl = this.sanitizer.bypassSecurityTrustResourceUrl(data.sDialogTopicVideoUrl); 

  }
  closeAlert() {
    this.activeModal.close();
  }
  ngOnInit() {
  }

}
