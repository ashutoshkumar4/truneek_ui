import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';

import { CourseService } from '../course.service';
import { Course } from '../course';
import { Observable } from 'rxjs';
import {
  mergeMap, switchMap, retry,
  map, catchError, filter, scan
} from 'rxjs/operators';
import { saveAs } from 'file-saver';
import { MatDialog } from '@angular/material';
import { VideopreviewComponent } from './videopreview/videopreview.component';
import { DomSanitizer, SafeResourceUrl, SafeUrl } from '@angular/platform-browser'

const MIME_TYPES = {
  pdf: 'application/pdf',
  xls: 'application/vnd.ms-excel',
  xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetxml.sheet'
}
@Component({
  selector: 'app-course-detail',
  templateUrl: './course-detail.component.html',
  styleUrls: ['./course-detail.component.css']
})

export class CourseDetailComponent implements OnInit {
  coursesDetailData: Course;
  public courseid: number;
  public courseslug: string;
  private error: any;
  public show: boolean = false;
  public collapseimg: any = 'plus';
  public collapupdownimg: any = 'downward';
  public isVideoExist = false;
  public activeClassName = 'classroom-training_id';
  public sCourseVideolink: any;
  public sFulldownloadLink: any;
  VideoUrl: SafeUrl;
  private ImageS3Url = '';

    constructor(private _courseService: CourseService,
    private route: ActivatedRoute,
    private router: Router,
    public dialog: MatDialog,
    public sanitizer: DomSanitizer,
    private modalService: NgbModal

  ) {
        this.ImageS3Url = _courseService.ImageS3Url;
   }


  setClassActive(activeClassName) {
    this.activeClassName = activeClassName;
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => this._courseService.getCourseDetails(params.get('id')).valueChanges)
    )
      .subscribe(
        (result) => {

          this.coursesDetailData = result.data && result.data.getSlugCourse;
          this.courseid = this.coursesDetailData.id;
          this.courseslug = this.coursesDetailData.course_slug;
          var aCourseSyllabusUrlData = JSON.parse(this.coursesDetailData.course_syllabus_url);
          this.sFulldownloadLink = aCourseSyllabusUrlData[0] && this._courseService.ImageS3Url + "/" + aCourseSyllabusUrlData[0].download_link;

          var aCourseVideoUrlData = JSON.parse(this.coursesDetailData.course_video_url);
          this.sCourseVideolink = aCourseVideoUrlData[0] && this._courseService.ImageS3Url + "/" + aCourseVideoUrlData[0].download_link;

          this.VideoUrl = this.sanitizer.bypassSecurityTrustResourceUrl(this.sCourseVideolink);
          // this.VideoUrl = this.sanitizer.bypassSecurityTrustUrl(this.sCourseVideolink); 

        },
        error => this.error = error
      );


  }
  downloadFile(fileName) {
    const EXT = fileName.substr(fileName.lastIndexOf('.') + 1);
    this._courseService.downloadFile({ 'fileName': fileName })
      .subscribe(data => {
        //save it on the client machine.
        saveAs(new Blob([data], { type: MIME_TYPES[EXT] }), fileName);
      })
  }
  openVideoDialog(sParamTopicVideoUrl) {
    const ngbModalOptions: NgbModalOptions = {
      size: 'lg',
      backdrop: 'static',
      keyboard: false
    };
    var aTopicVideoUrlData = JSON.parse(sParamTopicVideoUrl);
    var sTopicVideoUrl = aTopicVideoUrlData[0] && this._courseService.ImageS3Url + "/" + aTopicVideoUrlData[0].download_link;

    const modalRef = this.modalService.open(VideopreviewComponent, ngbModalOptions);
    modalRef.componentInstance.fileURL = sTopicVideoUrl;

    /*
    var aTopicVideoUrlData = JSON.parse(sParamTopicVideoUrl);
    var sTopicVideoUrl = this._courseService.ImageS3Url+"/" + aTopicVideoUrlData[0].download_link;

    this.dialog.open(VideopreviewComponent, {data:{sDialogTopicVideoUrl:sTopicVideoUrl}});
    */
  }

  ngAfterViewInit() {
    window.scrollTo(0, 0);
  }

 
}
