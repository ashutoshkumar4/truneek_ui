import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CourseRoutingModule } from './course-routing.module';
import { CourseListComponent } from './course-list/course-list.component';
import { CategoriesComponent } from './categories/categories.component';
import { CourseDetailComponent } from './course-detail/course-detail.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatVideoModule } from 'mat-video';
import { MatDialogModule, MAT_DIALOG_DEFAULT_OPTIONS } from "@angular/material";
import { VideopreviewComponent } from './course-detail/videopreview/videopreview.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ReadMoreComponent } from '../read-more/read-more.component';
import { NgbdRatingDecimal } from '../rating-decimal/rating-decimal';
import { ReqformComponent } from './course-detail/reqform/reqform.component';
import { ReactiveFormsModule } from '@angular/forms'
@NgModule({
  imports: [
    CommonModule,
    BrowserAnimationsModule,
    MatVideoModule,
    CourseRoutingModule,
    MatDialogModule,
    NgbModule,
    ReactiveFormsModule
  ],
  entryComponents: [VideopreviewComponent],
  exports: [

  ],
  providers: [
    { provide: MAT_DIALOG_DEFAULT_OPTIONS, useValue: { hasBackdrop: true, disableClose: true, height: 426 } }
  ],
  declarations: [CourseDetailComponent, VideopreviewComponent,ReadMoreComponent, NgbdRatingDecimal, ReqformComponent]
})
export class CourseModule { }
