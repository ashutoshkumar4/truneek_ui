import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpBackend ,HttpParams} from '@angular/common/http';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { Apollo, QueryRef ,Mutation} from 'apollo-angular';
import gql from 'graphql-tag';

@Injectable({
  providedIn: 'root'
})
export class CourseService {
  ServerUrl = environment.baseUrl;
  ImageS3Url = environment.ImageS3Url;

  private query: QueryRef<any>;
  errorData: {};
  constructor(private apollo: Apollo, handler: HttpBackend,
    private http:HttpClient) { }

  getAllCategories() {
    const ALL_CATEGORY_QUERY = gql`
    query  {
      getAllCategories
      {
      id
      category_name
      display_order
      }
    }
  `;
    this.query = this.apollo.watchQuery({
      query: ALL_CATEGORY_QUERY,
      //variables: {offset : 10*this.page}
    });

    return this.query;

  }

  getCourseByCategory(catid) {
    const CATEGORY_QUERY = gql`
  query  getCategory($paramcatid: ID!){
    getCategory(id: $paramcatid) {
      courses{
        id
	course_slug
        course_name
        course_short_description
        course_image_url
      }
    }
  }
`;
    this.query = this.apollo.watchQuery({
      query: CATEGORY_QUERY,
      variables: { paramcatid: catid }
    });

    return this.query;
  }

  getHomepageCourses(cnt) {
    const COURSES_QUERY = gql`
    query  getHomepageCourses($paramcnt: Int!){
      getHomepageCourses(count:$paramcnt){
        id
	course_slug
        categories_id
        course_name
        course_short_description
        course_image_url
      }
    }
  `;
    this.query = this.apollo.watchQuery({
      query: COURSES_QUERY,
      variables: { paramcnt: cnt }
    });

    return this.query;
  }

  getFooterCourses(cnt) {
    const COURSES_QUERY = gql`
    query  getFooterCourses($paramcnt: Int!){
      getFooterCourses(count:$paramcnt){
        id
	course_slug
        categories_id
        course_name
        course_short_description
        course_image_url
      }
    }
  `;
    this.query = this.apollo.watchQuery({
      query: COURSES_QUERY,
      variables: { paramcnt: cnt }
    });

    return this.query;
  }

  getRecentCourses() {
    const RECENT_QUERY = gql`
    query  {
      getRecentCourses(count:3){
        id
	course_slug
        categories_id
        course_name
        course_short_description
        course_image_url
      }
    }
  `;
    this.query = this.apollo.watchQuery({
      query: RECENT_QUERY,
      //variables: {offset : 10*this.page}
    });

    return this.query;
  }

  getTrendingCourses() {
    const TRENDING_QUERY = gql`
    query  {
      getTrendingCourses(count:3){
        id
	course_slug
        categories_id
        course_name
        course_short_description
        course_image_url
      }
    }
  `;
    this.query = this.apollo.watchQuery({
      query: TRENDING_QUERY,
      //variables: {offset : 10*this.page}
    });

    return this.query;
  }

  getCourseDetails(courseslug) {
    const COURSE_QUERY = gql`
  query  getSlugCourse($paramcourseslug: String!){
    getSlugCourse(slug: $paramcourseslug) {
        id
	course_slug
        categories_id
        course_name
        course_short_description
        course_image_url
        course_syllabus_url
        course_video_url
        homepage
        footer
        trending
        course_exam_certifications {
          id
          exam_item
          exam_content
        }        
        course_features {
          feature_content
        }
        course_lessions {
          lession_name
          course_lession_topics{
            topic_sequence
            topic_name
            topic_video_url
            is_preview
          }
        }        
        course_advisors {
          advisor_name
          id
          advisor_role
          advisor_image_url
          advisor_linkedin_url
	  advisor_description
        }
        course_descriptions {
          descriptions_item
          descriptions_content
          descriptions_image_url
          descriptions_video_url
        }
        course_faqs {
          faq_item
          faq_content
        }
        courses_reviews {
          reviewer_name
          review_rating
          reviewer_role
          review_comments
          reviewer_image_url
          reviewer_linkedin_url
        }
      }
  }
`;
    this.query = this.apollo.watchQuery({
      query: COURSE_QUERY,
      variables: { paramcourseslug: courseslug }
    });

    return this.query;
  }

  CreateContactInfo(contact_name,Email,phone,courses_id,individual,message) {
    const CREATE_CONTACT_INFO_QUERY = gql`
    mutation createContact(
      $Reqcontact_name: String!, 
      $ReqEmail: String!,
      $Reqphone: String!,
      $Reqcourses_id: ID!,
      $Reqindividual: Boolean!,
      $Reqmessage: String      
      ) {
      createContact(
        contact_name: $Reqcontact_name, 
        email: $ReqEmail,
        phone: $Reqphone,
        courses_id: $Reqcourses_id,
        individual: $Reqindividual,
        message: $Reqmessage
        ) {
        id
        contact_name
        email
        phone
        individual
        courses_id
        message        
      }
    }
  `;

    return  this.apollo.mutate({
    mutation: CREATE_CONTACT_INFO_QUERY,
    variables: { Reqcontact_name:contact_name,ReqEmail:Email,Reqphone:phone,Reqcourses_id:courses_id,Reqindividual:individual,Reqmessage:message }
    });

  }

  downloadFile(data) {
    // we would call the spring-boot service
    const REQUEST_PARAMS = new HttpParams().set('fileName', data.fileName);
    const REQUEST_URI = this.ImageS3Url+"/"+data.fileName;
    return this.http.get(REQUEST_URI, {
     // params: REQUEST_PARAMS,
      responseType: 'arraybuffer'
    })
  }

  
  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    this.errorData = {
      errorTitle: 'Sorry Request for data failed',
      errorDesc: 'Something bad happened. Please try again later.'
    };
    return throwError(this.errorData);
  }
}