import { Component, OnInit } from '@angular/core';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.css']
})
export class CourseListComponent implements OnInit {
  coursesData: any;
  recentCoursesData: {};
  trendingCoursesData: {};
  coursecatid: any;bas
  private error: any;
  ImageS3Url='';

  constructor(private _courseService: CourseService) {
    this.ImageS3Url = _courseService.ImageS3Url;
  }

  getCoursesbycatid(coursecatid) {
    if (coursecatid != 'ALL') {
      this._courseService.getCourseByCategory(coursecatid).valueChanges.subscribe(
        (result) => {
          this.coursesData = result.data && result.data.getCategory.courses;
        },
        error => this.error = error
      );
    }
    else {
      this._courseService.getHomepageCourses(6).valueChanges.subscribe(
        (result) => {
          this.coursesData = result.data && result.data.getHomepageCourses;
        },
        error => this.error = error
      );
    }

  }
  ngOnInit() {

    this._courseService.getHomepageCourses(6).valueChanges.subscribe(
      (result) => {
        this.coursesData = result.data && result.data.getHomepageCourses;
      },
      error => this.error = error
    );

    this._courseService.getRecentCourses().valueChanges.subscribe(
      (result) => {
        this.recentCoursesData = result.data && result.data.getRecentCourses;
      },
      error => this.error = error
    );

    this._courseService.getTrendingCourses().valueChanges.subscribe(
      (result) => {
        this.trendingCoursesData = result.data && result.data.getTrendingCourses;
      },
      error => this.error = error
    );
  }
}
