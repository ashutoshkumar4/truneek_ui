export class Course {
  id: number;
  categories_id: number;
  course_name: string;
  course_slug: string;
  course_short_description: string;
  course_image_url: string;
  course_video_url: string;
  course_syllabus_url:string;
  course_features: [{
    feature_content: string;
  }];
  course_lessions: [{
    lession_name: string;
    lession_syllabus_url: string;
    course_lession_topics: {
      topic_name: string;
      topic_video_url: string;
    }
  }];
  course_descriptions: [{
    descriptions_item: string;
    descriptions_image_url: string;
    descriptions_video_url: string;
  }];
  course_faqs: [{
    faq_item: string;
    faq_content: string;
  }];
  courses_reviews: [{
    reviewer_name: string;
    review_rating: number;
    reviewer_role: string;
    review_comments: string;
    reviewer_image_url: string;
    reviewer_linkedin_url: string;
  }];  
  course_advisors: [{
    advisor_name: string;
    advisor_role: string;
    advisor_description: string;
    advisor_image_url: string;
    advisor_linkedin_url: string;
  }];  
  course_exam_certifications: [{
    id: number;
    exam_item: string;
    exam_content: string;
  }]
}
