import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.css']
})
export class CategoriesComponent implements OnInit {
  categoriesData: any;
  private error: any;
  private selCatid: any;
  public activeClassName:any='ALL';

  @Output() public CatEvent = new EventEmitter();

  constructor(private _courseService: CourseService) { }

  SendCategory(selCatid) {
    this.CatEvent.emit(selCatid);
    this.activeClassName = selCatid;

  }
  ngOnInit() {
    this._courseService.getAllCategories().valueChanges.subscribe(
      (result) => {
        this.categoriesData = result.data && result.data.getAllCategories;
      },
      error => this.error = error
    );
  }

}
