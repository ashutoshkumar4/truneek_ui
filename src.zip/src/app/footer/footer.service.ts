import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpBackend } from '@angular/common/http';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { Apollo, QueryRef } from 'apollo-angular';
import gql from 'graphql-tag';

@Injectable({
  providedIn: 'root'
})
export class FooterService {
  ServerUrl = environment.baseUrl;
  private query: QueryRef<any>;
  errorData: {};

  constructor(private apollo: Apollo, handler: HttpBackend) { }


  
}
