import { Component, OnInit } from '@angular/core';
import { FooterService } from './footer.service';
import { CourseService } from '../course/course.service';
import { CmspageService } from '../cmspage/cmspage.service';
import { ConfigparamsService } from '../configparams.service';

import { Title } from '@angular/platform-browser';
import * as _ from 'lodash'; 

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  ContactData: any;
  TruneekData: any;
  error: any;
  HomeCoursesData: any;
  FooterCoursesData: any;
  footerTextData:any;
  fbTextData:any;
  twitterTextData:any;
  youtubeTextData:any;
  linkedinTextData:any;

  constructor(private titleService: Title,
    private _FooterService: FooterService, 
    private _CourseService: CourseService,
    private _CmspageService: CmspageService,
    private _configparamsService: ConfigparamsService,
    ) { }
    
  ngOnInit() {
    var aConfigPages = ["home-footer-contactus", "footer-disclaimer"];

    this._CmspageService.getPages(aConfigPages).valueChanges.subscribe(
      (result) => {
        this.ContactData = result.data && result.data.getPages;
        this.ContactData = _.find(this.ContactData, { 'page_name': 'home-footer-contactus'});
        this.ContactData =  this.ContactData.page_description;

        this.TruneekData = result.data && result.data.getPages;
        this.TruneekData = _.find(this.TruneekData, { 'page_name': 'footer-disclaimer'});
        this.TruneekData =  this.TruneekData.page_description;


      },
      error => this.error = error
    );
    /*
    this._CmspageService.getPage('footer-disclaimer').valueChanges.subscribe(
      (result) => {
        this.TruneekData = result.data && result.data.getPage.page_description;
      },
      error => this.error = error
    );
     */
    var aConfigParams = ["footer-text","facebook-url","twitter-url","youtube-url","linkedin-url"];

    this._configparamsService.getConfigParams(aConfigParams).valueChanges.subscribe(
      (result) => {
        this.footerTextData = result.data && result.data.getConfigParams;
        this.footerTextData = _.find(this.footerTextData, { 'config_param_key': 'footer-text'});
        this.footerTextData =  this.footerTextData.config_param_value;

        this.fbTextData = result.data && result.data.getConfigParams;
        this.fbTextData = _.find(this.fbTextData, { 'config_param_key': 'facebook-url'});
        this.fbTextData =  this.fbTextData.config_param_value;

        this.twitterTextData = result.data && result.data.getConfigParams;
        this.twitterTextData = _.find(this.twitterTextData, { 'config_param_key': 'twitter-url'});
        this.twitterTextData =  this.twitterTextData.config_param_value;

        this.youtubeTextData = result.data && result.data.getConfigParams;
        this.youtubeTextData = _.find(this.youtubeTextData, { 'config_param_key': 'youtube-url'});
        this.youtubeTextData =  this.youtubeTextData.config_param_value;

        this.linkedinTextData = result.data && result.data.getConfigParams;
        this.linkedinTextData = _.find(this.linkedinTextData, { 'config_param_key': 'linkedin-url'});
        this.linkedinTextData =  this.linkedinTextData.config_param_value;
      },
      error => this.error = error
    );   
    
    this._CourseService.getFooterCourses(6).valueChanges.subscribe(
      (result) => {
        this.FooterCoursesData = result.data && result.data.getFooterCourses;
      },
      error => this.error = error
    );

  }
  setPageTitle(title: string) {
    this.titleService.setTitle(title);
  }

}
