import { Injectable } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { Apollo, QueryRef } from 'apollo-angular';
import gql from 'graphql-tag';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class BannerService {
  //Variables declaration
  private query: QueryRef<any>;
  ImageS3Url = environment.ImageS3Url;

  errorData: {};

  constructor(private apollo: Apollo) { }

  getBanners() {
    const BANNER_QUERY = gql`
    query  {
      getAllBanners {
        id
        banner_image_url
        banner_link_url
      }
    }
  `;
    this.query = this.apollo.watchQuery({
      query: BANNER_QUERY,
      //variables: {offset : 10*this.page},
    });
    return this.query

  }
  public handleError(error: HttpErrorResponse) {
    if (error.message) {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error('An error occurred:', error.message);
    }
    // return an observable with a user-facing error message
    this.errorData = {
      errorTitle: 'Oops! Request for document failed',
      errorDesc: 'Something bad happened. Please try again later.'
    };
    return this.errorData;
  }
}
