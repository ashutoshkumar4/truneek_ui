import { Component, OnInit } from '@angular/core';
import { BannerService } from './banner.service';
import { environment } from '../../environments/environment';
import { ConfigparamsService } from '../configparams.service';

@Component({
  selector: 'app-banner',
  templateUrl: './banner.component.html',
  styleUrls: ['./banner.component.css']
})
export class BannerComponent implements OnInit {
  bannerimages = [];
  error: any;
  ImageS3Url='';
  constructor(private _BannerService: BannerService  
    ) { 
      this.ImageS3Url = _BannerService.ImageS3Url;

    }
  ngOnInit() {
    this._BannerService.getBanners().valueChanges.subscribe(
      (result) => {
        this.bannerimages = result.data && result.data.getAllBanners;
      },
      error => {
        this.error = this._BannerService.handleError(error);
      }
    );
  }



}
