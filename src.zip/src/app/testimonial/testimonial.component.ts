import { Component, OnInit } from '@angular/core';
import { TestimonialService } from './testimonial.service'
@Component({
  selector: 'app-testimonial',
  templateUrl: './testimonial.component.html',
  styleUrls: ['./testimonial.component.css']
})
export class TestimonialComponent implements OnInit {
  testimonialsData: any;
  private error: any;
  ImageS3Url='';
  constructor(private _testimonialService: TestimonialService) { 
    this.ImageS3Url = _testimonialService.ImageS3Url;
  }

  ngOnInit() {
    this._testimonialService.getAllTestimonials().valueChanges.subscribe(
      (result) => {
        this.testimonialsData = result.data && result.data.getAllTestimonials;
      },
      error => this.error = error
    );
  }
}