import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpBackend } from '@angular/common/http';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { Apollo, QueryRef } from 'apollo-angular';
import gql from 'graphql-tag';


@Injectable({
  providedIn: 'root'
})
export class TestimonialService {
  ServerUrl = environment.baseUrl;
  ImageS3Url = environment.ImageS3Url;

  private query: QueryRef<any>;
  errorData: {};
  constructor(private apollo: Apollo, handler: HttpBackend) { }

  getAllTestimonials() {
    const AllTestimonials_QUERY = gql`
    query  {
      getAllTestimonials{
        id
        user_name
        user_role
        testimonial
        user_image_url
      }
    }
  `;
    this.query = this.apollo.watchQuery({
      query: AllTestimonials_QUERY,
      //variables: {offset : 10*this.page}
    });
    return this.query;

  }

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    this.errorData = {
      errorTitle: 'Sorry Request for data failed',
      errorDesc: 'Something bad happened. Please try again later.'
    };
    return throwError(this.errorData);
  }

}
