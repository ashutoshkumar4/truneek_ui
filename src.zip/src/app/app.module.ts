import { BrowserModule, Title} from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { CmspageModule } from './cmspage/cmspage.module';
import { CourseModule } from './course/course.module';
import { AuthModule } from './auth/auth.module';
import { GraphQLModule } from './graphql.module';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { BannerComponent } from './banner/banner.component';
import { CourseListComponent } from './course/course-list/course-list.component';
import { CategoriesComponent } from './course/categories/categories.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { TestimonialComponent } from './testimonial/testimonial.component';
import { AgmCoreModule } from '@agm/core';
import { httpInterceptorProviders } from './http-interceptors/index';
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    PageNotFoundComponent,
    TestimonialComponent,
    BannerComponent,
    CourseListComponent,
    CategoriesComponent    
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    CmspageModule,
    CourseModule,
    AuthModule,
    AppRoutingModule,
    GraphQLModule,
    FormsModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyBkz0YPZ6sQvGqdoxn7BKiyKq5GYb6EKko'
    })
  ],
  providers: [Title, httpInterceptorProviders],
  bootstrap: [AppComponent]
})
export class AppModule { }
