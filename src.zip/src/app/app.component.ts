import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ConfigparamsService } from './configparams.service';
import { Title } from '@angular/platform-browser';
import { Meta } from '@angular/platform-browser';
import * as _ from 'lodash'; 
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'home';
  private error: any;
  configParamData : any;
  siteTitleConfigData : any;

  metaAuthor : any;
  metakeywords :any;
  metadescription :any;

  constructor(public router: Router,
    private _configparamsService: ConfigparamsService,
    private titleService: Title,
    private _meta: Meta
    ) {

    }
    ngOnInit() {
      
      var aConfigParam = ["site-title", "meta-author", "meta-keywords", "meta-description"];
      this._configparamsService.getConfigParams(aConfigParam).valueChanges.subscribe(
        (result) => {
         this.configParamData = result.data && result.data.getConfigParams;
         this.siteTitleConfigData = _.find(this.configParamData, { 'config_param_key': 'site-title'});
         this.siteTitleConfigData =  this.siteTitleConfigData.config_param_value
         
         var meta_keywords = _.find(this.configParamData, { 'config_param_key': 'meta-keywords'});
         meta_keywords =  meta_keywords.config_param_value
         this._meta.addTag({name: 'author', content: meta_keywords});
         
         var meta_author = _.find(this.configParamData, { 'config_param_key': 'meta-author'});
         meta_author =  meta_author.config_param_value
         this._meta.addTag({name: 'author', content: meta_author});

         var meta_description = _.find(this.configParamData, { 'config_param_key': 'meta-author'});
         meta_description =  meta_description.config_param_value
         this._meta.addTag({name: 'description', content: meta_description});
          this.setPageTitle('Home');
         },
        error => this.error = error
      );
    }

  setPageTitle(title: string) {
    title = this.siteTitleConfigData+' '+title;
    this.titleService.setTitle(title);
  }
}
