import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpBackend } from '@angular/common/http';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from '../environments/environment';
import { Apollo, QueryRef } from 'apollo-angular';
import gql from 'graphql-tag';

@Injectable({
  providedIn: 'root'
})
export class ConfigparamsService {
  ServerUrl = environment.baseUrl;
  ImageS3Url = environment.ImageS3Url;

  private query: QueryRef<any>;
  errorData: {};

  constructor(private apollo: Apollo, handler: HttpBackend) { }

  getConfigParams(aConfigName) {
    const CONFIGPARAMS_QUERY = gql`
  query  getConfigParams($aParamConfigName: [String]!){
    getConfigParams(key: $aParamConfigName) {
        config_param_key
        config_param_value
    }
  }
`;
    this.query = this.apollo.watchQuery({
      query: CONFIGPARAMS_QUERY,
      variables: { aParamConfigName: aConfigName }
    });

    return this.query;
  }

}
