import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { AuthService } from '../auth/auth.service';
import { ConfigparamsService } from '../configparams.service';
import * as _ from 'lodash'; 

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  public activeClassName = 'Home';
  siteTitleConfigData : any;
  private error: any;

  constructor( private titleService: Title, 
    private authService: AuthService,
    private _configparamsService: ConfigparamsService
    ) { }

  ngOnInit() {
    var aConfigParams = ["site-title"];

    this._configparamsService.getConfigParams(aConfigParams).valueChanges.subscribe(
      (result) => {
        this.siteTitleConfigData = result.data && result.data.getConfigParams;
        this.siteTitleConfigData = _.find(this.siteTitleConfigData, { 'config_param_key': 'site-title'});
        this.siteTitleConfigData =  this.siteTitleConfigData.config_param_value;

      },
      error => this.error = error
    );
  }

  get isLoggedIn() { return this.authService.isLoggedIn(); }

  setPageTitle(title: string) {
    this.activeClassName = title;

    title = this.siteTitleConfigData+' '+title;
    this.titleService.setTitle(title);
  }

}
