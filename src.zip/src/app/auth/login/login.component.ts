import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { CmspageService } from '../../cmspage/cmspage.service';
import * as _ from 'lodash'; 

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  submitted = false;
  returnUrl: string;
  error: {errorTitle: '', errorDesc: ''};
  loginError: string;
  loginData : any;
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private authService: AuthService,
    private _CmspageService: CmspageService,

    
    ) { }

  ngOnInit() {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
    var aConfigPages = ["login-text"];

    this._CmspageService.getPages(aConfigPages).valueChanges.subscribe(
      (result) => {
        this.loginData = result.data && result.data.getPages;
        this.loginData = _.find(this.loginData, {'page_name': 'login-text'});
        this.loginData =  this.loginData.page_description;
      },
      error => this.error = error
    );
    this.authService.logout();
  }

  get username() { return this.loginForm.get('username'); }
  get password() { return this.loginForm.get('password'); }

  onSubmit() {
    this.submitted = true;
    this.authService.login(this.username.value, this.password.value).subscribe((data) => {
       if (this.authService.isLoggedIn) {
          const redirect = this.authService.redirectUrl ? this.authService.redirectUrl : '/admin';
          this.router.navigate([redirect]);
        } else {
          this.loginError = 'Username or password is incorrect.';
        }
      },
      error => this.error = error
    );

  }
}
