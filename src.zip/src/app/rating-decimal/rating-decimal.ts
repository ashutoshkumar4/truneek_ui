import {Component, Input} from '@angular/core';

@Component({
  selector: 'ngbd-rating-decimal',
  templateUrl: './rating-decimal.html',
  styles: [`
    .star {
      position: relative;
      display: inline-block;
      font-size: 1rem;
      color: #d3d3d3;
    }
    .full {
      color: orange;
    }
    .half {
      position: absolute;
      display: inline-block;
      overflow: hidden;
      color: orange;
    }
  `]
})
export class NgbdRatingDecimal {
  @Input() currentRate: number;
}

